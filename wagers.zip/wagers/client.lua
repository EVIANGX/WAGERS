local spawnCoords = nil

function setSpawnCoords(coords)
    spawnCoords = coords
end

function teleportToSpawn()
    if spawnCoords then
        local playerPed = GetPlayerPed(-1)
        SetEntityCoords(playerPed, spawnCoords.x, spawnCoords.y, spawnCoords.z - 1, false, false, false, true)
        ESX.ShowNotification("Jūs perkelti atgal į arenos pradžios tašką.", "info", 3000)
    end
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)

        if spawnCoords then
            local playerPed = GetPlayerPed(-1)
            local playerCoords = GetEntityCoords(playerPed)

            local distance = #(playerCoords - vector3(spawnCoords.x, spawnCoords.y, spawnCoords.z))

            if distance > 20.0 then
                teleportToSpawn()
            end
        end
    end
end)


CreateThread(function ()
    initialiseNPC()
end)

function initialiseNPC()

lib.points.new(vec3(Config.NPC.x, Config.NPC.y, Config.NPC.z - 1), 50.0, {
    onEnter = function(self)
        if not self.ped then
            ESX.Streaming.RequestModel(`a_m_y_stlat_01`)
            self.ped = CreatePed(2, `a_m_y_stlat_01`, Config.NPC, false, true)
            FreezeEntityPosition(self.ped, true)
            SetEntityInvincible(self.ped, true)
            SetBlockingOfNonTemporaryEvents(self.ped, true)
            SetModelAsNoLongerNeeded(`a_m_y_stlat_01`)

            exports.ox_target:addLocalEntity(self.ped, {
                {
                    name = 'arena_menu',
                    label = 'Sukurti Wagerį',
                    icon = 'fas fa-crosshairs',
                    onSelect = function()
                        openFightCreationMenu()
                    end
                },
                {
                    name = 'arena_menu',
                    label = 'Prisijungti į Wagerį',
                    icon = 'fas fa-users',
                    onSelect = function()
                        openFightJoinMenu()
                    end
                }
            })
        end
    end,
    onExit = function(self)
        if self.ped then
            exports.ox_target:removeLocalEntity(self.ped, 'arena_create')
            DeleteEntity(self.ped)
            self.ped = nil
        end
    end,
})

end

function openFightCreationMenu()
    local weapons = {}

    for k,v in pairs(Config.weapons) do
        table.insert(weapons, {value = v, label = k})   
    end

    local input = lib.inputDialog('Sukurti arena', {
        {type = 'input', label = 'Slaptažodis', description = '', icon = 'fa-solid fa-key', required = true, min = 4, max = 16},
        {type = 'select', label = 'Komandos dydis', description = '', icon = 'fa-solid fa-users', options = {
            { value = "1v1", label = "1v1" },
            { value = "2v2", label = "2v2" },
            { value = "3v3", label = "3v3" }
        }},
        {type = 'select', label = 'Ginklas', description = '', icon = 'fa-solid fa-gun', options = weapons},
        {type = 'number', label = 'Bet', description = 'Kiek pinigų statote?', icon = 'fa-solid fa-dollar-sign'},
    })

    if input and input[1] and input[2] and input[3] and input[4] then
        lib.callback.await('pvpsystem:createFight', false, input[1], input[2], input[3], input[4])
    end
end

function openFightJoinMenu()
    local joinOptions = {}
    local currentFights = lib.callback.await('pvp:GetCurrentFights', false)
    
    if not currentFights then 
        return 
    end

    for creator, fight in pairs(currentFights) do
        table.insert(joinOptions, {
            title = fight.creator .. " ( Kiekis -" .. fight.teamSize .. ", Ginklas - " .. fight.weapon .. ", Statomi pinigai - $" .. fight.bet .. ")",
            onSelect = function()
                local input = lib.inputDialog("Įveskite slaptažodį", {"Slaptažodis"})
                if input and input[1] then
                    lib.callback.await('pvpsystem:joinFight', false, fight.id, input[1])
                end
            end
        })
    end    

    lib.registerContext({
        id = 'fight_join_menu',
        title = 'Prisijungti į Wagerį',
        options = joinOptions
    })

    lib.showContext('fight_join_menu')
end

function ViewPlayers(players, fightID, team)
    local options = {}

    for k,v in pairs(players) do
        table.insert(options, {
            title = v.name,
            onSelect = function()
                local alert = lib.alertDialog({
                    header = 'Žaidėjo išmetimas',
                    content = string.format('Ar jūs įsitikinęs, kad norite išmesti %s žaidėją?', v.name),
                    centered = true,
                    cancel = true
                })

                print(alert)

                if alert == 'confirm' then
                lib.callback.await('pvpsystem:kickPlayer', false, fightID, v.player)
                end
            end
        })
    end

    lib.registerContext({
        id = 'fight_view_players',
        title = string.format('%s nariai', team),
        menu = 'fight_view_menu',
        options = options
    })
    
    lib.showContext('fight_view_players')

end

lib.callback.register('pvpsystem:viewFight', function(fight, creator)
    local fightOptions = {
        {
            title = "Komanda 1 turi " .. #fight.team1 .. " žaidėjų",
            description = 'Peržiūrėti komandos žaidėjus.',
            onSelect = function()
                ViewPlayers(fight.team1, fight.id, 'Komanda 1')
            end
        },
        {
            title = "Komanda 2 turi " .. #fight.team2 .. " žaidėjų",
            description = 'Peržiūrėti komandos žaidėjus.',
            onSelect = function()
                ViewPlayers(fight.team2, fight.id, 'Komanda 2')
            end
        },
        {
            title = "Išeiti iš kovos",
            onSelect = function()
                lib.callback.await('pvpsystem:leaveArena', false)
            end
        }
    }

    if creator and not fight.started then
        table.insert(fightOptions, {
                title = "Pradėti Wagerį",
                onSelect = function()
                    if #fight.team1 == Config.teamSizes[fight.teamSize] / 2 and #fight.team2 == Config.teamSizes[fight.teamSize] / 2 then
                        lib.callback.await('pvpsystem:startFight', false, fight.id)
                    else
                        ESX.ShowNotification("Komandos nėra pilnos.", "error", 3000)
                    end
                end
            }
        )
    end

    lib.registerContext({
        id = 'fight_view_menu',
        title = 'Peržiūrėti Wagerį',
        options = fightOptions
    })

    lib.showContext('fight_view_menu')
end)

lib.callback.register('pvpsystem:startFightClient', function(spawnCoords)
    setSpawnCoords(spawnCoords)
    local playerPed = GetPlayerPed(-1)
    local plyState = LocalPlayer.state
    SetEntityCoords(playerPed, spawnCoords.x, spawnCoords.y, spawnCoords.z - 1, false, false, false, true)
    SetEntityHeading(playerPed, spawnCoords.heading)
    plyState:set('invBusy', true, true)

    FreezeEntityPosition(playerPed, true)
    Wait(5000)
    ESX.ShowNotification("Kova prasidėjo!")
    FreezeEntityPosition(playerPed, false)
    plyState:set('invBusy', false, false)
end)


lib.callback.register('pvpsystem:roundReset', function(scores, spawnCoords)
    local playerPed = GetPlayerPed(-1)
    local plyState = LocalPlayer.state

    Wait(5000)
    TriggerEvent('ox_inventory:disarm', true)
    plyState:set('invBusy', true, true)
    TriggerEvent('esx_ambulancejob:revive')
    Wait(1500)
    ESX.ShowNotification("Roundo pabaiga, Taškai: " .. scores.team1 .. " - " .. scores.team2, "info", 3000)

    FreezeEntityPosition(playerPed, true)
    SetEntityCoords(playerPed, spawnCoords.x, spawnCoords.y, spawnCoords.z - 1, false, false, false, true)
    SetEntityHeading(playerPed, spawnCoords.heading)
    Wait(5000) 
    FreezeEntityPosition(playerPed, false)
    plyState:set('invBusy', false, false)
end)

lib.callback.register('pvpsystem:endFight', function(winningTeam)
        Wait(5000)
        TriggerEvent('esx_ambulancejob:revive')
        Wait(1500)
    
        if winningTeam == 1 then 
            winningTeam = 'pirma komanda' 
        elseif winningTeam == 2 then 
            winningTeam = 'antra komanda' 
        end
    
        ESX.ShowNotification("Kova pasibaigė, Laimėjo: " .. winningTeam, "success", 5000)
    
        Wait(1200)
        SetEntityCoords(GetPlayerPed(-1), Config.NPC.x, Config.NPC.y, Config.NPC.z - 1, false, true, true, false)
        SetEntityHeading(GetPlayerPed(-1), Config.NPC.heading)
    
        setSpawnCoords(nil)
    end)
    