Config = {}

Config.weapons = {
    ["Pistoletas"] = "weapon_pistol",
    ["Combat Pistoletas"] = "weapon_combatpistol",
    ["Ceramic Pistoletas"] = "weapon_ceramicpistol",
    ["Mini Smg"] = "weapon_minismg",
    ["Pistol 50"] = "WEAPON_PISTOL50",
    ["Sns Pistoletas"] = "weapon_snspistol",
    ["Marksman Pistoletas"] = "weapon_marksmanpistol",
    ["Ap Pistoletas"] = "weapon_appistol",
    ["Revolveris"] = "weapon_revolver",
    ["Double Action Revolveris"] = "weapon_doubleaction",
    ["Pump Shotgun"] = "weapon_pumpshotgun",
    ["BullPuP rifle"] = "weapon_bullpuprifle",
    ["Special carbine"] = "weapon_specialcarbine",
    ["Military Rifle"] = "weapon_militaryrifle",
    ["Sniper Rifle"] = "weapon_sniperrifle",
    ["Heavy sniper"] = "weapon_heavysniper",
    ["Combat pdw"] = "WEAPON_COMBATPDW",
    ["Carbine rifle"] = "WEAPON_CARBINERIFLE",
    ["Heavy rifle"] = "WEAPON_HEAVYRIFLE",
    ["Musket"] = "WEAPON_MUSKET",
    ["Navy Revolver"] = "WEAPON_NAVYREVOLVER",
    ["RPG"] = "WEAPON_RPG",
    ["Assault Rifle"] = "weapon_assaultrifle"
}

Config.roundCount = 3

Config.NPC = vec(-545.1268, -218.2930, 36.6498, 305.2848)

Config.spawnCoords = {
    ["1v1"] = {
        team1 = {
            vec(-949.1650, -801.8520, 15.9211, 325.0699)
        },
        team2 = {
            vec(-933.6448, -781.3612, 15.9212, 149.5255)
        },
    },
    ["2v2"] = {
        team1 = {
            vec(-950.8239, -799.9810, 15.9210, 329.2770),
            vec(-946.1914, -802.9341, 15.9211, 324.6665)
        },
        team2 = {
            vec(-931.9866, -783.9792, 15.9210, 150.1462),
            vec(-936.3854, -780.2245, 15.9212, 122.9389)
        },
    },
    ["3v3"] = {
        team1 = {
            vec(-949.1650, -801.8520, 15.9211, 325.0699),
            vec(-950.8239, -799.9810, 15.9210, 329.2770),
            vec(-946.1914, -802.9341, 15.9211, 324.6665)
        },
        team2 = {
            vec(-949.1650, -801.8520, 15.9211, 325.0699),
            vec(-931.9866, -783.9792, 15.9210, 150.1462),
            vec(-936.3854, -780.2245, 15.9212, 122.9389)
        },
    },
}

Config.teamSizes = {
    ["1v1"] = 2,
    ["2v2"] = 4,
    ["3v3"] = 6
}
